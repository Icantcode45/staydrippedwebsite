# Customization Guide

All site components can be found in the `components` directory. Edit these HTML fragments to modify individual sections without touching `index.html`.

Styles are authored in `assets/css`. Adjust variables in `style.css` to tweak colors or fonts across the site.
