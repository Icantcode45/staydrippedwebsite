# Deployment Guide

1. Ensure all static assets are built and optimized.
2. Upload the contents of this repository to your static hosting provider (e.g. Netlify or GitHub Pages).
3. Configure the `CNAME` file or DNS settings to point your domain to the host.
